Timelendar – Avertissement de sécurité / Security warning
=========================================================

---------- FRANÇAIS ----------

Contourner l'avertissement de sécurité (app non signée)

L'application n'est pas signée (pas de certificat payant). Windows et macOS
peuvent afficher un avertissement. Ce n'est pas dangereux : le logiciel est sain.

--- WINDOWS ---
• Au premier lancement, Windows Defender / SmartScreen peut bloquer l'exécutable.
• Option 1 : Clic droit sur l'exécutable → "Exécuter quand même"
  (ou "More info" puis "Run anyway" selon la langue).
• Option 2 : Paramètres Windows → Mise à jour et sécurité → Sécurité Windows →
  Protection contre les applications et les navigateurs → Paramètres des applications
  et du navigateur → Bloquer ou autoriser → ajouter une exception si besoin.
• Vous pouvez aussi ajouter le dossier de l'app en exclusion antivirus
  si votre logiciel le permet.


--- MAC ---
• Au premier lancement, macOS peut indiquer que l'app provient d'un développeur
  non identifié.
• Ouvrir Préférences Système → Sécurité et confidentialité → onglet Général.
• Cliquer sur "Ouvrir quand même" à côté du message concernant Timelendar.
• Ou : clic droit sur l'application → Ouvrir → confirmer "Ouvrir".

--- EN CAS DE DOUTE ---
Vous pouvez vérifier le code source du projet (dépôt privé) ou nous contacter.
Nous restons transparents : pas de licence de signature tant que ce n'est pas
rentable, mais aucun code malveillant.


---------- ENGLISH ----------

Bypassing the security warning (unsigned app)

The app is not signed (no paid certificate). Windows and macOS may show
a warning. This is not dangerous: the software is safe.

--- WINDOWS ---
• On first launch, Windows Defender / SmartScreen may block the executable.
• Option 1: Right-click the executable → "Run anyway"
  (or "More info" then "Run anyway" depending on language).
• Option 2: Windows Settings → Update & Security → Windows Security →
  App & browser control → App and browser control settings →
  Block or allow → add an exception if needed.
• You can also add the app folder to your antivirus exclusions
  if your software allows it.


--- MAC ---
• On first launch, macOS may say the app is from an unidentified developer.
• Open System Preferences → Security & Privacy → General tab.
• Click "Open Anyway" next to the message about Timelendar.
• Or: right-click the application → Open → confirm "Open".

--- IF IN DOUBT ---
You can check the project source code (private repo) or contact us.
We stay transparent: no signing license while it's not profitable,
but no malicious code.
